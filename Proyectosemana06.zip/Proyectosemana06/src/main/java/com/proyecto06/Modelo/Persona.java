package com.proyecto06.Modelo;
public class Persona {
    private String dni;
    private String nombre;
    private double sueldo;
    public Persona(){}
    public String getDni() {    return dni;    }
    public void setDni(String dni) {    this.dni = dni;    }
    public String getNombre() {     return nombre;    }
    public void setNombre(String nombre) {      this.nombre = nombre;    }
    public double getSueldo() {      return sueldo;   }
    public void setSueldo(double sueldo) {       this.sueldo = sueldo;    }    
}
